# JLplay4 — Proyecto Android inicial ampliado

## Incluido
- Interfaz Android en español: Inicio, Inventario, Ventas, Gastos e Informes.
- Base de datos SQLite local; las operaciones básicas funcionan sin Internet.
- Inventario con plataforma, estado, costo, precio, moneda y cantidad.
- Registro de ventas con descuento automático de stock y método de pago.
- Registro de gastos.
- Resúmenes separados por USD, CUP y EUR; USD es la moneda inicial.
- Exportación mediante el selector de archivos de Android:
  - CSV con ventas, gastos e inventario, compatible con Excel.
  - PDF con resumen por moneda e inventario.
- PIN local de 4 a 8 dígitos, con hash SHA-256 y sal, más botón para bloquear la aplicación.

## Limitaciones y seguridad
- El PIN es una barrera de acceso a la interfaz; no cifra la base SQLite. Protege el teléfono con bloqueo de pantalla y no compartas los archivos exportados.
- No hay sincronización en la nube, deliberadamente.
- Los informes son acumulados; aún faltan filtros por fecha, tasas de cambio y conversión a USD.
- Antes de usarlo como contabilidad definitiva, probar todas las operaciones y conservar exportaciones de respaldo.

## Cómo compilar
1. Instala Android Studio en una computadora.
2. Descomprime el ZIP y abre la carpeta `JLplay4_Android_Starter`.
3. Espera la sincronización de Gradle.
4. Ejecuta en un emulador o dispositivo Android.
5. Usa **Build > Build Bundle(s) / APK(s) > Build APK(s)** para generar un APK de prueba.

Este ZIP contiene código fuente; no es un APK compilado y verificado.
