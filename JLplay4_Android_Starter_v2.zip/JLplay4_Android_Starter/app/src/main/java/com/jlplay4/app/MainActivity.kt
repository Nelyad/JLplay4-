package com.jlplay4.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.security.MessageDigest
import java.security.SecureRandom

private val currencies = listOf("USD", "CUP", "EUR")
data class Product(val id: Long, val name: String, val platform: String, val condition: String,
    val cost: Double, val price: Double, val currency: String, val quantity: Int)

class JLDatabase(context: Context) : SQLiteOpenHelper(context, "jlplay4.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, platform TEXT NOT NULL, condition TEXT NOT NULL, cost REAL NOT NULL, price REAL NOT NULL, currency TEXT NOT NULL, quantity INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE sales (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, product_name TEXT, quantity INTEGER, unit_price REAL, cost_each REAL, currency TEXT, payment TEXT, created_at TEXT)")
        db.execSQL("CREATE TABLE expenses (id INTEGER PRIMARY KEY AUTOINCREMENT, description TEXT, amount REAL, currency TEXT, category TEXT, created_at TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun addProduct(name: String, platform: String, condition: String, cost: Double, price: Double, currency: String, quantity: Int) {
        val v = ContentValues().apply {
            put("name", name); put("platform", platform); put("condition", condition)
            put("cost", cost); put("price", price); put("currency", currency); put("quantity", quantity)
        }
        writableDatabase.insert("products", null, v)
    }
    fun products(): List<Product> {
        val result = mutableListOf<Product>()
        readableDatabase.rawQuery("SELECT * FROM products ORDER BY name", null).use { c ->
            while (c.moveToNext()) result.add(Product(
                c.getLong(c.getColumnIndexOrThrow("id")), c.getString(c.getColumnIndexOrThrow("name")),
                c.getString(c.getColumnIndexOrThrow("platform")), c.getString(c.getColumnIndexOrThrow("condition")),
                c.getDouble(c.getColumnIndexOrThrow("cost")), c.getDouble(c.getColumnIndexOrThrow("price")),
                c.getString(c.getColumnIndexOrThrow("currency")), c.getInt(c.getColumnIndexOrThrow("quantity"))))
        }
        return result
    }
    fun addSale(p: Product, qty: Int, payment: String): Boolean {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val check = db.rawQuery("SELECT quantity FROM products WHERE id = ?", arrayOf(p.id.toString()))
            val available = check.use { c -> if (c.moveToFirst()) c.getInt(0) else -1 }
            if (available < qty) return false
            db.execSQL("UPDATE products SET quantity = quantity - ? WHERE id = ?",
                arrayOf(qty, p.id))
            val v = ContentValues().apply {
                put("product_id", p.id); put("product_name", p.name); put("quantity", qty)
                put("unit_price", p.price); put("cost_each", p.cost); put("currency", p.currency)
                put("payment", payment); put("created_at", now())
            }
            db.insert("sales", null, v)
            db.setTransactionSuccessful()
            return true
        } finally { db.endTransaction() }
    }
    fun addExpense(description: String, amount: Double, currency: String, category: String) {
        val v = ContentValues().apply {
            put("description", description); put("amount", amount); put("currency", currency)
            put("category", category); put("created_at", now())
        }
        writableDatabase.insert("expenses", null, v)
    }
    fun totals(currency: String): Triple<Double, Double, Double> {
        fun sum(sql: String): Double {
            readableDatabase.rawQuery(sql, arrayOf(currency)).use { c ->
                return if (c.moveToFirst()) c.getDouble(0) else 0.0
            }
        }
        val revenue = sum("SELECT COALESCE(SUM(quantity * unit_price),0) FROM sales WHERE currency = ?")
        val cost = sum("SELECT COALESCE(SUM(quantity * cost_each),0) FROM sales WHERE currency = ?")
        val expenses = sum("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE currency = ?")
        return Triple(revenue, cost, expenses)
    }
    fun exportCsv(): String {
        val out = StringBuilder()
        out.append("TIPO,FECHA,PRODUCTO/CATEGORIA,CANTIDAD,IMPORTE,COSTO,MONEDA,METODO/ESTADO\n")
        readableDatabase.rawQuery("SELECT product_name,quantity,unit_price,cost_each,currency,payment,created_at FROM sales ORDER BY id", null).use { c ->
            while (c.moveToNext()) {
                out.append(listOf("VENTA", c.getString(6), c.getString(0), c.getString(1),
                    c.getString(2), c.getString(3), c.getString(4), c.getString(5))
                    .joinToString(",") { csv(it ?: "") }).append("\n")
            }
        }
        readableDatabase.rawQuery("SELECT description,amount,currency,category,created_at FROM expenses ORDER BY id", null).use { c ->
            while (c.moveToNext()) {
                out.append(listOf("GASTO", c.getString(4), c.getString(0), "", c.getString(1),
                    "", c.getString(2), c.getString(3)).joinToString(",") { csv(it ?: "") }).append("\n")
            }
        }
        readableDatabase.rawQuery("SELECT name,platform,condition,cost,price,currency,quantity FROM products ORDER BY name", null).use { c ->
            while (c.moveToNext()) {
                out.append(listOf("INVENTARIO", "", c.getString(0), c.getString(6), c.getString(4),
                    c.getString(3), c.getString(5), "${c.getString(1)} ${c.getString(2)}")
                    .joinToString(",") { csv(it ?: "") }).append("\n")
            }
        }
        return out.toString()
    }

    fun pdfRows(currency: String): List<String> {
        val t = totals(currency)
        val rows = mutableListOf(
            "Moneda del informe: $currency",
            "Ventas registradas: ${money(t.first, currency)}",
            "Costo de productos vendidos: ${money(t.second, currency)}",
            "Ganancia bruta: ${money(t.first - t.second, currency)}",
            "Gastos registrados: ${money(t.third, currency)}",
            "Beneficio estimado: ${money(t.first - t.second - t.third, currency)}",
            "",
            "INVENTARIO"
        )
        products().forEach { p ->
            rows.add("${p.name} | ${p.platform} | ${p.condition} | Stock ${p.quantity} | Venta ${money(p.price,p.currency)}")
        }
        return rows
    }

    private fun csv(value: String): String = "\"" + value.replace("\"", "\"\"") + "\""

    private fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = JLDatabase(this)
        setContent { JLPlay4App(db) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JLPlay4App(db: JLDatabase) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("jlplay4_security", Context.MODE_PRIVATE) }
    var unlocked by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf("") }
    var page by remember { mutableStateOf("Inicio") }
    var refresh by remember { mutableIntStateOf(0) }
    var currency by remember { mutableStateOf("USD") }
    val products = remember(refresh) { db.products() }
    val totals = remember(refresh, currency) { db.totals(currency) }
    val csvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) try {
            context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(db.exportCsv()) }
            Toast.makeText(context, "CSV exportado", Toast.LENGTH_LONG).show()
        } catch (e: Exception) { Toast.makeText(context, "No se pudo exportar: ${e.message}", Toast.LENGTH_LONG).show() }
    }
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) try {
            context.contentResolver.openOutputStream(uri)?.use { output ->
                val doc = PdfDocument()
                val paint = Paint().apply { textSize = 12f; isAntiAlias = true }
                var pageNo = 1
                var pdfPage = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
                var canvas = pdfPage.canvas
                canvas.drawText("JLplay4 - Informe del negocio", 40f, 42f, Paint(paint).apply { textSize = 18f; isFakeBoldText = true })
                var y = 72f
                db.pdfRows(currency).forEach { line ->
                    if (y > 800f) {
                        doc.finishPage(pdfPage); pageNo++
                        pdfPage = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
                        canvas = pdfPage.canvas; y = 45f
                    }
                    canvas.drawText(line.take(95), 40f, y, paint)
                    y += 19f
                }
                doc.finishPage(pdfPage)
                doc.writeTo(output)
                doc.close()
            }
            Toast.makeText(context, "PDF exportado", Toast.LENGTH_LONG).show()
        } catch (e: Exception) { Toast.makeText(context, "No se pudo exportar: ${e.message}", Toast.LENGTH_LONG).show() }
    }
    val pages = listOf("Inicio", "Inventario", "Ventas", "Gastos", "Informes")
    MaterialTheme(colorScheme = darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF9B87F5))) {
        if (!unlocked) {
            val hasPin = prefs.contains("pinHash")
            Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
                Text("JLplay4", style = MaterialTheme.typography.headlineLarge)
                Text(if (hasPin) "Introduce tu PIN" else "Crea un PIN para proteger el acceso")
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(8) },
                    label = { Text("PIN de 4 a 8 dígitos") }, modifier = Modifier.fillMaxWidth())
                if (!hasPin) {
                    OutlinedTextField(confirmPin, { confirmPin = it.filter(Char::isDigit).take(8) },
                        label = { Text("Repite el PIN") }, modifier = Modifier.fillMaxWidth())
                }
                if (pinError.isNotBlank()) Text(pinError, color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    if (pin.length !in 4..8) pinError = "El PIN debe tener entre 4 y 8 dígitos."
                    else if (!hasPin && pin != confirmPin) pinError = "Los PIN no coinciden."
                    else if (!hasPin) {
                        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
                        prefs.edit().putString("pinSalt", salt.joinToString("") { "%02x".format(it) })
                            .putString("pinHash", pinHash(pin, salt)).apply()
                        unlocked = true; pinError = ""
                    } else {
                        val saltHex = prefs.getString("pinSalt", "") ?: ""
                        val salt = hexToBytes(saltHex)
                        if (pinHash(pin, salt) == prefs.getString("pinHash", null)) {
                            unlocked = true; pinError = ""
                        } else pinError = "PIN incorrecto."
                    }
                    pin = ""; confirmPin = ""
                }, modifier = Modifier.fillMaxWidth()) { Text(if (hasPin) "Entrar" else "Crear PIN") }
                Spacer(Modifier.height(8.dp))
                Text("El PIN protege la apertura de la app. Mantén también seguro el bloqueo de tu teléfono.")
            }
            return@MaterialTheme
        }
        Scaffold(
            topBar = { TopAppBar(title = { Column {
                Text("JLplay4")
                Text("Contabilidad gamer", style = MaterialTheme.typography.labelSmall)
            } }, actions = { Icon(Icons.Default.SportsEsports, contentDescription = null, modifier = Modifier.padding(end = 16.dp)) }) },
            bottomBar = { NavigationBar { pages.forEach { p ->
                val icon = when(p) {
                    "Inicio" -> Icons.Default.Dashboard
                    "Inventario" -> Icons.Default.Inventory
                    "Ventas" -> Icons.Default.ShoppingCart
                    "Gastos" -> Icons.Default.Payments
                    else -> Icons.Default.Assessment
                }
                NavigationBarItem(selected = page == p, onClick = { page = p }, icon = { Icon(icon, null) }, label = { Text(p) })
            } } }
        ) { padding ->
            key(page) {
                Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                    when(page) {
                        "Inicio" -> Home(currency, { currency = it }, totals, products.size)
                        "Inventario" -> Inventory(db, products) { refresh++ }
                        "Ventas" -> Sales(db, products) { refresh++ }
                        "Gastos" -> Expenses(db) { refresh++ }
                        "Informes" -> Reports(currency, { currency = it }, totals, { csvLauncher.launch("JLplay4_datos.csv") }, { pdfLauncher.launch("JLplay4_informe.pdf") }, { unlocked = false })
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CurrencyPicker(value: String, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(value, {}, readOnly = true, label = { Text("Moneda") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth())
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            currencies.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { onChange(c); expanded = false }) }
        }
    }
}

@Composable
fun Metric(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(12.dp)) {
        Text(title, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(6.dp))
        Text(value, style = MaterialTheme.typography.titleMedium)
    } }
}
@Composable
fun Home(currency: String, change: (String) -> Unit, t: Triple<Double,Double,Double>, count: Int) {
    Text("Panel principal", style = MaterialTheme.typography.headlineMedium)
    Text("Resumen acumulado por moneda")
    Spacer(Modifier.height(12.dp)); CurrencyPicker(currency, change); Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Metric("Ventas", money(t.first, currency), Modifier.weight(1f))
        Metric("Ganancia bruta", money(t.first-t.second, currency), Modifier.weight(1f))
    }
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Metric("Gastos", money(t.third, currency), Modifier.weight(1f))
        Metric("Beneficio estimado", money(t.first-t.second-t.third, currency), Modifier.weight(1f))
    }
    Spacer(Modifier.height(12.dp))
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
        Text("Inventario", style = MaterialTheme.typography.titleMedium)
        Text("$count productos registrados")
        Text("Los importes de monedas distintas se mantienen separados.")
    } }
}

@Composable
fun Inventory(db: JLDatabase, products: List<Product>, saved: () -> Unit) {
    var name by remember { mutableStateOf("") }; var platform by remember { mutableStateOf("PS4") }
    var condition by remember { mutableStateOf("Usado") }; var cost by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }; var currency by remember { mutableStateOf("USD") }
    var quantity by remember { mutableStateOf("1") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Inventario", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(name, { name = it }, label = { Text("Nombre del juego") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(platform, { platform = it }, label = { Text("Plataforma") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(condition, { condition = it }, label = { Text("Estado: nuevo/usado") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(cost, { cost = it }, label = { Text("Costo") }, modifier = Modifier.weight(1f))
            OutlinedTextField(price, { price = it }, label = { Text("Precio venta") }, modifier = Modifier.weight(1f))
        }
        CurrencyPicker(currency, { currency = it })
        OutlinedTextField(quantity, { quantity = it }, label = { Text("Cantidad") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            val c = cost.toDoubleOrNull(); val p = price.toDoubleOrNull(); val q = quantity.toIntOrNull()
            if (name.isNotBlank() && c != null && p != null && q != null && c >= 0 && p >= 0 && q >= 0) {
                db.addProduct(name.trim(), platform, condition, c, p, currency, q)
                name = ""; cost = ""; price = ""; quantity = "1"; saved()
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Guardar producto") }
        Spacer(Modifier.height(12.dp)); Text("Productos (${products.size})", style = MaterialTheme.typography.titleMedium)
        products.forEach { p -> Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Column(Modifier.padding(12.dp)) {
                Text(p.name, style = MaterialTheme.typography.titleMedium)
                Text("${p.platform} · ${p.condition} · Stock: ${p.quantity}")
                Text("Costo ${money(p.cost,p.currency)} | Venta ${money(p.price,p.currency)}")
            }
        } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Sales(db: JLDatabase, products: List<Product>, saved: () -> Unit) {
    var selected by remember { mutableStateOf<Product?>(null) }; var qty by remember { mutableStateOf("1") }
    var payment by remember { mutableStateOf("Efectivo") }; var expanded by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Registrar venta", style = MaterialTheme.typography.headlineMedium)
        if (products.none { it.quantity > 0 }) Text("Añade productos con existencias desde Inventario.")
        else {
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(selected?.let { it.name + " — " + money(it.price,it.currency) } ?: "Seleccionar producto",
                    {}, readOnly = true, label = { Text("Producto") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    products.filter { it.quantity > 0 }.forEach { p ->
                        DropdownMenuItem(text = { Text("${p.name} · stock ${p.quantity}") },
                            onClick = { selected = p; expanded = false })
                    }
                }
            }
            OutlinedTextField(qty, { qty = it }, label = { Text("Cantidad") }, modifier = Modifier.fillMaxWidth())
            var payExpanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = payExpanded, onExpandedChange = { payExpanded = !payExpanded }) {
                OutlinedTextField(payment, {}, readOnly = true, label = { Text("Método de pago") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(payExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = payExpanded, onDismissRequest = { payExpanded = false }) {
                    listOf("Efectivo", "Transferencia", "Otro").forEach {
                        DropdownMenuItem(text = { Text(it) }, onClick = { payment = it; payExpanded = false })
                    }
                }
            }
            selected?.let { Text("Total: ${money(it.price * (qty.toIntOrNull() ?: 0), it.currency)}") }
            Button(onClick = {
                val p = selected; val q = qty.toIntOrNull()
                if (p != null && q != null && q > 0 && q <= p.quantity && db.addSale(p,q,payment)) {
                    selected = null; qty = "1"; saved()
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("Confirmar venta") }
        }
    }
}

@Composable
fun Expenses(db: JLDatabase, saved: () -> Unit) {
    var description by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf("USD") }; var category by remember { mutableStateOf("General") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Registrar gasto", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(description, { description = it }, label = { Text("Descripción") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(amount, { amount = it }, label = { Text("Importe") }, modifier = Modifier.fillMaxWidth())
        CurrencyPicker(currency, { currency = it })
        OutlinedTextField(category, { category = it }, label = { Text("Categoría") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            val n = amount.toDoubleOrNull()
            if (description.isNotBlank() && n != null && n > 0) {
                db.addExpense(description.trim(), n, currency, category)
                description = ""; amount = ""; saved()
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Guardar gasto") }
    }
}

@Composable
fun Reports(currency: String, change: (String) -> Unit, t: Triple<Double,Double,Double>,
            exportCsv: () -> Unit, exportPdf: () -> Unit, lockApp: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Informes", style = MaterialTheme.typography.headlineMedium)
        Text("Resumen acumulado por moneda")
        Spacer(Modifier.height(12.dp)); CurrencyPicker(currency, change)
        ReportLine("Ventas", money(t.first,currency))
        ReportLine("Costo de productos vendidos", money(t.second,currency))
        ReportLine("Ganancia bruta", money(t.first-t.second,currency))
        ReportLine("Gastos", money(t.third,currency))
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        ReportLine("Beneficio estimado", money(t.first-t.second-t.third,currency))
        Spacer(Modifier.height(16.dp))
        Button(onClick = exportCsv, modifier = Modifier.fillMaxWidth()) { Text("Exportar datos a Excel (CSV)") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = exportPdf, modifier = Modifier.fillMaxWidth()) { Text("Exportar informe PDF") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = lockApp, modifier = Modifier.fillMaxWidth()) { Text("Bloquear JLplay4") }
        Spacer(Modifier.height(12.dp))
        Text("El CSV incluye ventas, gastos e inventario y se puede abrir con Excel. El PDF incluye resumen e inventario. Elige dónde guardar cada archivo.")
    }
}

private fun pinHash(pin: String, salt: ByteArray): String {
    val digest = MessageDigest.getInstance("SHA-256")
    digest.update(salt)
    return digest.digest(pin.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
private fun hexToBytes(hex: String): ByteArray = if (hex.isBlank()) ByteArray(0) else
    hex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()

@Composable
fun ReportLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, Modifier.weight(1f)); Text(value, style = MaterialTheme.typography.titleMedium)
    }
}
fun money(value: Double, currency: String) = String.format(Locale.US, "%s %.2f", currency, value)
